//: Playground - noun: a place where people can play

import Cocoa

let numberOfStoplights: Int = 4
var population: Int
population = 5422
let townName: String = "Knowhere"
let townDescription =
    "\(townName) has a population of \(population) and \(numberOfStoplights) stoplights."
print(townDescription)